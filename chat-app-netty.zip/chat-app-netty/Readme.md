## Refer:

- protopuf with reactjs / nodejs: https://webapplog.com/json-is-not-cool-anymore/

- build `repeated` property protopuf java:

  - https://stackoverflow.com/questions/29170183/how-to-set-repeated-fields-in-protobuf-before-building-the-message
  - https://stackoverflow.com/questions/32081493/how-to-set-google-protobuf-repeated-field-in-java


- netty-rest *** / CORS: https://github.com/yjmyzz/netty-rest
